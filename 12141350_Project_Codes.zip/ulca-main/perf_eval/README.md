1. To generate data, run:

  `python3 data_generation.py`

2. To generate ULCA's evaluation results, run:

  `python3 perf_eval_ucla.py`

3. To generate the backward algorithm's evaluation results, run:

  `python3 perf_eval_backward.py`

4. To generate plots of evaluation results, run:

  `python3 plotting.py`
