To generate results in the supplementary material, run

`python3 dr_comp.py`
